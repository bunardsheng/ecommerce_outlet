FactoryBot.define do
  factory :category do
    name { "Cookware" }
    active { true }
  end
end
