class ItemsController < ApplicationController
    include AppHelpers::Shipping
    before_action :set_item, only: [:show, :edit, :update, :destroy, :toggle_feature, :toggle_active]
    before_action :check_login, only: [:show, :edit, :update, :destroy]
    authorize_resource

    def new
        @item = Item.new
    end

    def index
        @categories = Category.all
        @category = params[:category]

        if @category.present? 
            @specific_category = Category.find(@category)
            @featured_items = Item.active.featured.for_category(@specific_category)
            @other_items = Item.active.for_category(@specific_category) - @featured_items

        else 
            @featured_items = Item.all.featured
            @other_items = Item.all.active.alphabetical - @featured_items
        end
    end

    def show
        if (logged_in? and current_user.role?(:admin))
            @prices = @item.item_prices.chronological.to_a
        end

        @all_items = Item.for_category(@item.category).active.alphabetical.to_a
        @similar_items = @all_items - [@item]
    end

    def destroy
        if !@item.destroy
            redirect_back fallback_location: item_path(@item)
        else
            redirect_to items_path
        end
    end

    def create
        @item = Item.new(item_params)
        if @item.save
            redirect_to item_path(@item), notice: "#{@item.name} was added to the system."
        else
            render action: 'new'
        end
    end

    def update
        if @item.update_attributes(item_params)
            redirect_to item_path(@item)
        else 
            render action: 'edit'
        end
    end
    
    def toggle_feature
        if @item.is_featured
            @item.update_attribute(:is_featured, false)
            flash[:notice] = "#{@item.name} is no longer featured"
        else 
            @item.update_attribute(:is_featured, true)
            flash[:notice] = "#{@item.name} is now featured"
        end

        redirect_back fallback_location: home_path
    end

    def toggle_active
        #if the item is active
        if @item.active
            @item.make_inactive
            flash[:notice] = "#{@item.name} was made inactive"
        
        else #if the item is not active
            @item.make_active
            flash[:notice] = "#{@item.name} was made active"
        end

        redirect_back fallback_location: home_path
    end

    private
    def set_item
        @item = Item.find(params[:id])
    end

    def item_params
        params.require(:item).permit(:name, :description, :color, :inventory_level, :reorder_level, :category_id, :weight, :is_featured, :active)
    end

end
