class SearchController < ApplicationController
    
    def search
        if params[:query].blank?
            redirect_back fallback_location: home_path
        end

        if current_user.role?(:customer)
            @customers = nil
            @query = params[:query]
            @items = Item.search(@query)
            @total_hits = @items.size
           
            
        else
            @customers = Customer.search(@query)
            @query = params[:query]
            @items = Item.search(@query)
            @total_hits = @items.size + @customers.size
        end
    end
end
