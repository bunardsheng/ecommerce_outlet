class OrdersController < ApplicationController
    include AppHelpers::Cart
    include AppHelpers::Shipping
    
    before_action :set_order, only: [:show, :edit, :update, :destroy]
    before_action :check_login, only: [:show, :edit, :update, :destroy]
    

    def index
        if current_user.role?(:admin)
            @all_orders = Order.all.paginate(page: params[:page]).per_page(15)
            @pending_orders = Order.not_shipped.all.paginate(page: params[:page]).per_page(15)
            @past_orders = @all_orders - @pending_orders
        else 
            @all_orders = Order.for_customer(current_user.customer).all.paginate(page: params[:page]).per_page(15)
            @past_orders = nil
        end

    end

    def show
        @previous_orders = @order.customer.orders.chronological.to_a - [@order]

        @order_items = @order.order_items
    end

    def create
        @order = Order.new(order_params)
        @order.date = Date.current
        @order.shipping = calculate_shipping_costs(@order.total_weight)
        @order.products_total = calculate_cart_items_cost

        if @order.save
            flash[:notice] = "Thank you for ordering from GPBO."
            redirect_to order_path(Order.last)
        else
            redirect_back fallback_location: checkout_path
        end
    end

   
    private

    def set_order
        @order = Order.find(params[:id])
    end

    def order_params
        params.require(:order).permit(:customer_id, :address_id, :date, :products_total, :tax, :shipping, :payment_receipt, :credit_card_number, :expiration_year, :expiration_month)
    end

    
end