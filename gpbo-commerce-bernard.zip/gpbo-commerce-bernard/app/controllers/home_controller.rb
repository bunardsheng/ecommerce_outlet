class HomeController < ApplicationController
    
    def index
    end
  
    def about
    end
  
    def contact
    end
  
    def privacy
    end

    def search
        
    end
end